package br.com.coimbra;


public class Main {

	/*
	 * public static void main (String[] args) {
	 * 
	 * System.out.println(Status.E);
	 * 
	 * }
	 */

}
