package br.com.coimbra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevcoimbraApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevcoimbraApplication.class, args);
	}

}
