package br.com.coimbra.dao;

import org.springframework.stereotype.Repository;

import br.com.coimbra.domain.Cliente;

@Repository
public class ClienteDaoImp extends AbstractDao<Cliente, Long> implements ClienteDao {
	

}
